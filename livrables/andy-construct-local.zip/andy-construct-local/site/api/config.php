<?php
// Configuration LOCALE (générée par tools/export/export_local.py).
// Mode test : aucun e-mail ni webhook réel ; tout est écrit dans api/stockage/.
declare(strict_types=1);
$base = require __DIR__ . '/config.example.php';
return array_replace_recursive($base, [
    'mode_test' => true,
    'url_site' => 'http://localhost:8000',
    'url_api' => 'http://localhost:8000/api',
    'origines_autorisees' => ['http://localhost:8000', 'http://127.0.0.1:8000'],
    'stockage' => __DIR__ . '/stockage',
    'secrets' => ['hmac_webhook' => '4aec86fe43cd4f68b8d7993404694bca73ea7b4b6d58fa084ef4fd43a5266bf8', 'actions' => '61816b426695d19a45fc95789682485fd7b3078af70aa93b7b9dc55d2d647089', 'local' => '9b4f7f41daafea6e5830e1332963b023f15675d3583127ebcaadb554a19547ca', 'admin' => '07514c6c0e77caf4627eafcf3ef5923fd1385e1408c774fc6838fe66b0d37358'],
    'smtp' => ['actif' => false],
    'n8n' => ['simuler' => true],
    'pages' => ['merci_devis' => '/merci.html', 'merci_rappel' => '/merci.html', 'merci_envoi_postal_guide' => '/merci.html'],
    'admin' => ['url' => 'http://localhost:8000/admin'],
]);
