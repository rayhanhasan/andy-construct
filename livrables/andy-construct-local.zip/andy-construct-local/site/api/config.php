<?php
// Configuration LOCALE (générée par tools/export/export_local.py).
// Mode test : aucun e-mail ni webhook réel ; tout est écrit dans api/stockage/.
declare(strict_types=1);
$base = require __DIR__ . '/config.example.php';
return array_replace_recursive($base, [
    'mode_test' => true,
    'url_site' => 'http://localhost:8000',
    'url_api' => 'http://localhost:8000/api',
    'origines_autorisees' => ['http://localhost:8000', 'http://127.0.0.1:8000'],
    'stockage' => __DIR__ . '/stockage',
    'secrets' => ['hmac_webhook' => 'e760a3282c1eb5ae33a20041a699b178cb392c02ab10f3676ac7941b2d31ca06', 'actions' => '0c1b1f7e0e249a9ef88c5619f7ac04b5b3ebe7bc23c69c9ff76cc012ef8273c8', 'local' => '6a624d49245d4cecd43aa11b39e3b7bf0a6456eaa98a3c97d085e332492643b2', 'admin' => '7108c415b06d11ab748f1f4ab9143913ce8aae57d0a7d95ce7f94ea7f4c012b8'],
    'smtp' => ['actif' => false],
    'n8n' => ['simuler' => true],
    'pages' => ['merci_devis' => '/merci.html', 'merci_rappel' => '/merci.html', 'merci_envoi_postal_guide' => '/merci.html'],
    'admin' => ['url' => 'http://localhost:8000/admin'],
]);
