<?php
// Configuration LOCALE (générée par tools/export/export_local.py).
// Mode test : aucun e-mail ni webhook réel ; tout est écrit dans api/stockage/.
declare(strict_types=1);
$base = require __DIR__ . '/config.example.php';
return array_replace_recursive($base, [
    'mode_test' => true,
    'url_site' => 'http://localhost:8000',
    'url_api' => 'http://localhost:8000/api',
    'origines_autorisees' => ['http://localhost:8000', 'http://127.0.0.1:8000'],
    'stockage' => __DIR__ . '/stockage',
    'secrets' => ['hmac_webhook' => 'e843c6d47fd9fb259e1b1a8e7e88efd7c0fc8d5e70185f3cd45a5a4e579568a3', 'actions' => 'fb95a17a465afa2925c89f0d2183d46c96b60f54dfd0df1a04abc6ec68965c20', 'local' => 'd3463238a2930e2c2d9b661edba3f411a9cad7f095ba897e855b72fea4d6d2bd', 'admin' => '0bf68c1b2480a16b16b76d9aa6cbb3a8af666b2299ceb1bacd1019290b30528f'],
    'smtp' => ['actif' => false],
    'n8n' => ['simuler' => true],
    'pages' => ['merci_devis' => '/merci.html', 'merci_rappel' => '/merci.html', 'merci_envoi_postal_guide' => '/merci.html'],
    'admin' => ['url' => 'http://localhost:8000/admin'],
]);
