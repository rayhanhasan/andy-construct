<?php
// Configuration LOCALE (générée par tools/export/export_local.py).
// Mode test : aucun e-mail ni webhook réel ; tout est écrit dans api/stockage/.
declare(strict_types=1);
$base = require __DIR__ . '/config.example.php';
return array_replace_recursive($base, [
    'mode_test' => true,
    'url_site' => 'http://localhost:8000',
    'url_api' => 'http://localhost:8000/api',
    'origines_autorisees' => ['http://localhost:8000', 'http://127.0.0.1:8000'],
    'stockage' => __DIR__ . '/stockage',
    'secrets' => ['hmac_webhook' => 'cfb083ab664804f718b5fd36793d35c6d20e0b77b87982847feaba8b491d5379', 'actions' => '9423d52ea84f0b934faab55795955e1aca991ca0b23b4b638f288c172592719b', 'local' => 'd227fc80b4d22462090596557fb86a61338bdf21699462e5ee8e7dc382cf5ecf', 'admin' => '73ac20c67474e03bcfebca9cdebb83821fe384cb446a06b4321977e227968ebf'],
    'smtp' => ['actif' => false],
    'n8n' => ['simuler' => true],
    'pages' => ['merci_devis' => '/merci.html', 'merci_rappel' => '/merci.html', 'merci_envoi_postal_guide' => '/merci.html'],
    'admin' => ['url' => 'http://localhost:8000/admin'],
]);
