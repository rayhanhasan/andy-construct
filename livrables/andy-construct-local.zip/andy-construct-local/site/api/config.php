<?php
// Configuration LOCALE (générée par tools/export/export_local.py).
// Mode test : aucun e-mail ni webhook réel ; tout est écrit dans api/stockage/.
declare(strict_types=1);
$base = require __DIR__ . '/config.example.php';
return array_replace_recursive($base, [
    'mode_test' => true,
    'url_site' => 'http://localhost:8000',
    'url_api' => 'http://localhost:8000/api',
    'origines_autorisees' => ['http://localhost:8000', 'http://127.0.0.1:8000'],
    'stockage' => __DIR__ . '/stockage',
    'secrets' => ['hmac_webhook' => '4823e7e2453d6e7d78f8adea87bb6474cae41612cbb9117c3e8a2d8d1b8f459d', 'actions' => '4a53d1319ba8b8fee346ea5f028f464a7ab7ee474365159c043ea111ee40add2', 'local' => 'b6bf2825476a63e425bb6fccd4b226c0186f61434dbdfbf906f85d2965caa6b3', 'admin' => 'ad78c4fdce18820c5e0359b9ccb802b85316f12e813e76e8aa864a38df6e36ce'],
    'smtp' => ['actif' => false],
    'n8n' => ['simuler' => true],
    'pages' => ['merci_devis' => '/merci.html', 'merci_rappel' => '/merci.html', 'merci_envoi_postal_guide' => '/merci.html'],
    'admin' => ['url' => 'http://localhost:8000/admin'],
]);
