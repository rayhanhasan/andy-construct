<?php
// Configuration LOCALE (générée par tools/export/export_local.py).
// Mode test : aucun e-mail ni webhook réel ; tout est écrit dans api/stockage/.
declare(strict_types=1);
$base = require __DIR__ . '/config.example.php';
return array_replace_recursive($base, [
    'mode_test' => true,
    'url_site' => 'http://localhost:8000',
    'url_api' => 'http://localhost:8000/api',
    'origines_autorisees' => ['http://localhost:8000', 'http://127.0.0.1:8000'],
    'stockage' => __DIR__ . '/stockage',
    'secrets' => ['hmac_webhook' => 'f6318d6e7669eb8d92ddfdeac72c1a3129aca2799f32eb1bcde91c65ebc456aa', 'actions' => 'af0188935fe301aa475a1d87e52692f5d9123466234a0731a4087973be7d7bf0', 'local' => 'abbf73200022907d1c1df6a5133852b668b57907b7a21ae7926b8423b12049ca', 'admin' => '167215090c1debba0f5f8185a1633e8e622bd7b56f48f20b4cd76432583a4375'],
    'smtp' => ['actif' => false],
    'n8n' => ['simuler' => true],
    'pages' => ['merci_devis' => '/merci.html', 'merci_rappel' => '/merci.html', 'merci_envoi_postal_guide' => '/merci.html'],
    'admin' => ['url' => 'http://localhost:8000/admin'],
]);
