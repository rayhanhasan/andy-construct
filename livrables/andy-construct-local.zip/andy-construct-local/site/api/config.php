<?php
// Configuration LOCALE (générée par tools/export/export_local.py).
// Mode test : aucun e-mail ni webhook réel ; tout est écrit dans api/stockage/.
declare(strict_types=1);
$base = require __DIR__ . '/config.example.php';
return array_replace_recursive($base, [
    'mode_test' => true,
    'url_site' => 'http://localhost:8000',
    'url_api' => 'http://localhost:8000/api',
    'origines_autorisees' => ['http://localhost:8000', 'http://127.0.0.1:8000'],
    'stockage' => __DIR__ . '/stockage',
    'secrets' => ['hmac_webhook' => 'dc63f66bdcc0d875d954701e669b091adedb2925b50a7d247f0576d4b630c7e3', 'actions' => '764b2769874a35a2e911c5c5d60569d0608b4e00f70d18d9f0f405a0f9778241', 'local' => '0fc502a89074146f6bea0ef7b9cf6dcf41ee30a81f49b409201d20dafce2bf0d', 'admin' => 'e24085193bb575ba07360e78d5211fd9ebad8705f62485d64f005975c4d8407c'],
    'smtp' => ['actif' => false],
    'n8n' => ['simuler' => true],
    'pages' => ['merci_devis' => '/merci.html', 'merci_rappel' => '/merci.html', 'merci_envoi_postal_guide' => '/merci.html'],
    'admin' => ['url' => 'http://localhost:8000/admin'],
]);
